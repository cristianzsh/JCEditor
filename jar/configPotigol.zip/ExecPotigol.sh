#!/bin/bash
# affiche_param.sh

caminho="$1"
nomeArquivo="$2"
pathPotigol="${HOME}/ConfigJCE/.potigol/potigol.jar"

gnome-terminal --title="$nomeArquivo - Potigol" -x bash -c "java -jar $pathPotigol -w -c $caminho; printf 'Pressione enter para sair...'; read; exit 0; exec $SHELL";
