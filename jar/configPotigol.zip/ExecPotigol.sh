#!/bin/bash
# affiche_param.sh

caminho="$1"
nomeArquivo="$2"
pathPotigol="${HOME}/ConfigJCE/.potigol/potigol.jar"
p1="Pressione"
p2="enter"
p3="para"
p4="sair..."

gnome-terminal --title="$2 - Potigol" -x bash -c "java -jar $pathPotigol $caminho; echo $p1 $p2 $p3 $p4; read; exit 0; exec $SHELL";
